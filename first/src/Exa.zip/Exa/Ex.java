package Exa;

public class Ex {
	public static void main(String[] args) {
		int sum = 0;
		for (int j = 0; j <= 100; j++) {
			if(j/2==1) {
				sum=sum+j;
			}
			
		}System.out.println(sum);
	}
	
}
